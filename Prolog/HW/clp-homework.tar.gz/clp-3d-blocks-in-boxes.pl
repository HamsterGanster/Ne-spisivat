/*
 * 3d version of the 'blocks-in-boxes' problem.
 * We keep using predefined blocks instead of
 * getting them as a CLI parameters, because
 * it is of no matter now.
 */

:- use_module(library(clpr)).

:- op(400, xfx, inside).


% Blocks
% Now blocks have not only width and height but z-dimensions.
% Let us denote blocks' dimentions as _x, _y and _z.
block(b1, d(1.0, 3.0, 2.0)).
block(b2, d(2.0, 2.0, 1.0)).
block(b3, d(2.0, 1.0, 1.0)).
block(b4, d(2.0, 1.0, 1.0)).
block(b5, d(1.0, 1.0, 1.0)).
block(b6, d(1.0, 1.0, 1.0)).
block(b7, d(1.0, 1.0, 1.0)).
block(b8, d(1.0, 1.0, 1.0)).

% Boxes

box(box1, d(6.0, 6.0, 6.0)).
box(box2, d(3.0, 3.0, 2.0)).

% rot(?Rect, ?RotatedRect)
% Rotation of rectangle in the 3-dimensional space
%
% ZX and YX rotations has a redundant constraints
% _y =\= _z which is needed to cut off unnecessary
% backtracks. Consider the following example:
%
% rot(_, d(2, 1, 1), R).
% There is only 3 different rotations:
% R = (2, 1, 1)
% R = (1, 2, 1)
% R = (1, 1, 2)
% But without the constraint redundancy rotation rules could return
% redundant solutions, already been returned by the previous rules.


% <YOUR CODE HERE>


% Place block into a box, which means assign a minimal rectangle
% that accomodates a block.
% place_block(+BlockName, -Place).
% Place = rect(Pos, Dim).


% <YOUR CODE HERE>


% inside(+Rect1, +Rect2)
% The predicate holds iff Rect1 is completely inside Rect2


% <YOUR CODE HERE>


% no_overlap(+Rect1, +Rect2)
% Holds iff Rect1 and Rect2 do not overlap
%
% Note that we added redundant constraints in order
% to prevent unnecessary backtracks. It is better
% than adding cuts, because they destroys the
% declarative semantics of constraints.


% <YOUR CODE HERE>
