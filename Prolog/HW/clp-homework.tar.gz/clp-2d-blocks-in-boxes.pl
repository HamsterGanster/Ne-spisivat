/*
 * More general solution of the 2-dimensional 'blocks-in-boxes' problem.
 * The predicate arrange/2 now gets a name of a box and a list of blocks in a form
 * [BlockName/BlockRect, ...].
 */

:- use_module(library(clpr)).

:- op(400, xfx, inside).
:- op(400, xfx, no_overlap).

% Placing blocks into a box
%
% block(+BlockName, +BlockDim).
% BlockDim = d(W, H) - block dimensions (size).
%
%  ___________________
% |                   |
% |                   |
% |                   |
%  -------------------
% y
% ^
% |
% ---> x
%
% There are 4 predefined blocks.

block(b1, d(5.0, 3.0)).
block(b2, d(2.0, 6.0)).
block(b3, d(1.0, 2.4)).
block(b4, d(1.0, 5.0)).

% Also there are 3 different boxes

box(box1, d(6.0, 6.0)).
box(box2, d(7.0, 5.0)).
box(box3, d(6.0, 5.0)).

% Representation of rectangular space a block occupied inside a container is the following:
% rect(+Pos, +Dim)
% Pos = pos(X, Y) - coordinates of the bottom-left corner of a block.
% Dim = d(W, H)   - block's dimensions
%
% rect/2 represents a rectangle of a size W, H at the position (X, Y).
%
% The position of a rectangle in a box is determined by the coordinates of the left-bottom corner of a
% rectangle, relative to the left-bottom corner of the box.

% rot(?Rect, ?RotatedRect)
% Possible rotations of a rectangle in the 2-dimensional space. It is obvious enough that a rectangular
% block can only be in two positions: d(W, H) or d(H, W).

rot(rect(Pos, Dim), rect(Pos, Dim)). % Zero rotation
rot(rect(Pos, d(W, H)), rect(Pos, d(H, W))). % Rotated by 90 degrees

% Place block into a box, which means assign a minimal rectangle that accomodates a block.
% place_block(+BlockName, -Place).
% Place = rect(Pos, Dim).

place_block(BlockName, rect(Pos, Dim)) :-
    % Get a block
    block(BlockName, BDim),
    % Block could be rotated to fit the position
    % Note that it could be a zero rotation
    rot(rect(Pos, BDim), rect(Pos, Dim)).

% inside(+Rect1, +Rect2)
% The predicate holds iff Rect1 is completely inside Rect2
inside(rect(pos(X1, Y1), d(W1, H1)), rect(pos(X2, Y2), d(W2, H2))) :-
    {X1 >= X2,               % X1 must be on the right-hand side of X2
     Y1 >= Y2,
     X1 + W1 =< X2 + W2,     % Rect1 must not go beyond Rect2
     Y1 + H1 =< Y2 + H2}.


% no_overlap(+Rect1, +Rect2)
% Holds iff Rect1 and Rect2 do not overlap
no_overlap(rect(pos(X1, Y1), d(W1, H1)), rect(pos(X2, Y2), d(W2, H2))) :-
    { X1 + W1 =< X2 ; % Rectangles are left or right of each other
      X2 + W2 =< X1 ;
      Y1 + H1 =< Y2 ; % Rectangles are above or below of each other
      Y2 + H2 =< Y1 }.

% arrange(+Box, ?Arranged, ?NotArranged)
% Box         : Box name
% Arranged    : List of blocks that are already arranged in the box
% NotArranged : List of blocks that are not arranged yet
arrange(_, _, []).
arrange(Box, Arranged, [Bname/Bi|Bs]) :-
    place_block(Bname, Bi),
    Bi inside Box,
    maplist(no_overlap(Bi), Arranged),
    arrange(Box, [Bi|Arranged], Bs).

% arrange(+BoxName, +Blocks)
% BoxName  : name of the box we want to fit blocks into
% Blocks   : list of blocks where each element has a following form:
%            BlockName/Rectangle
%
% ?- arrange(box1, [b1/R1,b2/R2,b3/R3,b4/R4]).
% R1 = rect(pos(1.0, 3.0), d(5.0, 3.0)),
% R2 = rect(pos(0.0, 1.0), d(6.0, 2.0)),
% R3 = rect(pos(0.0, _A), d(1.0, 2.4)),
% R4 = rect(pos(1.0, 0.0), d(5.0, 1.0)),
% {_A=<3.6, _=3.0-_A, _A>=3.0} ;
% ...
arrange(BoxName, Blocks) :-
    box(BoxName, BoxDim),               % find the box
    Box = rect(pos(0.0, 0.0), BoxDim),  % Box is a rectangular place occupied by the box
    arrange(Box, [], Blocks).
